var app = angular.module('drag', ['ngMaterial', 'ngMessages',"ngRoute"]);
app.controller('Ctrl',function($scope){
  console.log('inside');
  $scope.remove = function(event){
  console.log(event);
  console.log(event.currentTarget.parentNode.parentNode.attributes.id.value);
  var el = document.querySelector("#"+event.currentTarget.parentNode.parentNode.attributes.id.value).outerHTML="";
  console.log(el);
}
});

$( function() {
    $( "#sortable" ).sortable();
    $( "#sortable" ).disableSelection();
} );

$( function() {
  $( "#sortable" ).resizable();
} );
